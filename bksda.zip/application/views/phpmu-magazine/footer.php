<?php
echo "<div class='wrapper'>
	<div class='header-logo'>";
		$iden = $this->model_utama->view('identitas')->row_array();
		$logo = $this->model_utama->view_ordering_limit('logo','id_logo','DESC',0,1);
		foreach ($logo->result_array() as $row) {
			echo "<a href='".base_url()."'><img style='max-height:120px' src='".base_url()."asset/logo/$row[gambar]'/></a>";
		}
	echo "</div>	

	<div class='header-menu'>
		<h3>
		KEMENTERIAN LINGKUNGAN HIDUP DAN KEHUTANAN <br>
		DIREKTORAT JENDRAL KONSERVASI SUMBER DAYA ALAM DAN EKOSISTEM <br>
		BALAI KONSERVASI SUMBER DAYA ALAM SUMATERA SELATAN
		</h3>
		<p>
		Jl. Kol. H . Burlian / Punti Kayu Km 6 No 79. Palembang<br>
		Telepon: (0711) 410948 | Email: bksdasumsel@yahoo.co.id
		</p>
	</div>
	<ul class='right'>";
		$topmenu2 = $this->model_utama->view_where_ordering_limit('menu',array('position' => 'Top','aktif' => 'Ya'),'urutan','ASC',0,5);
			foreach ($topmenu2->result_array() as $row) {
			echo "<li><a href='$row[link]'>$row[nama_menu]</a></li>";
		}
	echo "</ul>

	<p>&copy; ".date('Y')." Copyright <b>BKSDA SUMSEL</b>. All Rights reserved.</p>
</div>";
?>