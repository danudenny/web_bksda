<?php
header ('Location:http://balaiksdasumsel.org');
?>